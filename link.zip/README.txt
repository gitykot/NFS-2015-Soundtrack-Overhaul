Link: https://drive.google.com/file/d/1ireGmLJL5wQNtUBHWZ8tBgGGPxnFYPjh/view?usp=sharing


Greetings to all. This is the first mod from our team, this mod replaces the entire game soundtrack with a new one. This is a list of all the songs:


Main Menu:
1. Pharmacist, Juicy J - Popped
2. Cushy - Sledgehammers
3. MUPP - Punishment
4. Skeler - For You
5. Slowboy, IVOHYGEN - Hiding
6. TroyBoi - Say Yeah


Credits:
1. Kiljo, DVRKLXGHT - Demons
2. SXMPRA, Bone Thugs-N-Harmony - LET'S RIDE! - Drift Phonk


Garage:
1. Snoop Dog, The Doors - Riders On The Storm - Fredwreck Remix (Need for Speed: Underground 2)
2. rock - I Am Rock (Need for Speed: Most Wanted)
3. Terror Squad, Fat Joe, Remy Ma - Lean Back (Need for Speed: Underground 2)
4. JUVENILE, Wacko - Sets Go Up (Need for Speed: Most Wanted)
5. Ekstrak - Belt (Need for Speed: Carbon)
6. Future - Mask Off
7. TroyBoi - Say Yeah
8. Hush - Fired Up (Need for Speed: Most Wanted)
9. Pop Smoke - Element
10. LXST CXNTURY, Juicy J - MUSIC DEALER
11. P$C, Young Dro - Do Ya Thing (Need for Speed: Most Wanted)
12. DJ Spooky, Dave Lombardo - B-SIDE Wins Again (Need for Speed: Most Wanted)
13. Night Lovell - PLEASE DON'T GO
14. Lupe Fiasco - Titled (Need for Speed: Most Wanted)
15. Xavier Wulf, Quintin Lamb - Cars & Coffee
16. Adam the Shinobi, FOURTYFOURMEMPHIS - Up Ta Sumthing
17. ROONIN - MONEY : POWER
18. Hensonn - Sahara
19. Liz_thatsilent - Relaxed preparation
20. Night Lovell - Counting Down the List
21. Kiljo, DVRKLXGHT - Demons
22. OBLXKQ - SCARFACE


Freeroam:
1. DaniLeigh - No Limits (Skeler Remix)
2. KUTE, BLESSED MANE - NIGHT RIDE
3. Capone - I Need Speed (Need for Speed: Underground 2)
4. Felix Da Housecat - Rocket Ride (Soulwax Remix) (Need for Speed: Underground 2)
5. Pop Smoke - Invincible
6. Paul Van Dyk - Nothing But You (Cirrus Remix) (Need for Speed: Underground 2)
7. Styles Of Beyond, Grant Mohrman - Nine Thou (Grant Mohrman Superstars Remix) (Need for Speed: Most Wanted)
8. Petey Pablo - Need for Speed (Need for Speed: Underground)
9. YCK - Count Me Out
10. MUPP, INTERWORLD, glichery - infinite universe
11. do not resurrect - 2077
12. Slevpy808 - Comin Round
13. MUZZ, Celldweller - New Age
14. do not resurrect - Takeshi Kovacs Concerto in F Minor
15. quiizzzmeow, Midix - KATANA
16. Demxn - Frequency
17. DVRST, Scarlxrd - Always Want Me
18. Scarlxrd - Missing Antidxte


Racing:
1. Desturbed - Decadence (Need for Speed: Most Wanted)
2. Static-X - The Only (Need for Speed: Underground)
3. Jeremiah Kane, Leo Iwasaki - THE END
4. Evol Intent & Mayhem, Thinktank - Broken Sword (Need for Speed: Most Wanted)
5. g3ox_em, $NOT - Demon
6. Celldweller, Styles of Beyound - Shapeshifter (Need for Speed: Most Wanted)
7. Teriyaki Boyz - Tokyo Drift (Eurobeat Remix)
8. Bulled For My Valentine - Hand Of Blood (Need for Speed: Most Wanted)
9. STRLGHT, ROONIN - BACK2BACK
10. Khantrast - Cyberfreak
11. Static-X - Skinnyman (Need for Speed: Most Wanted)
12. Atari Teenage Riot - Speed


Drift:
1. Future - POA
2. KIR1IXCHE, trixq - DEADLY DANCE
3. MIERNØ, Naski - ANNUAL BLØØD SPILLAGE
4. Pendulum - 9,000 Miles
5. Project 98 - Busta
6. Yellowcard - Breathing
7. Sonic Animation - E-Ville (Need for Speed: Underground 2)
8. Magnolia Park, Ethan Ross, PLVTINUM - Animal
9. Magnolia Park, Kayzo, Ethan Ross - Oblivion Eyes
10. tourniquet - Pretty Cvnt
11. The Prodigy - You'll Be UNDER MY WHEELS (Need for Speed: Most Wanted)
12. Cushy - spot
13. Pharmacist, Bearded Legend, Sagath - RUIN


Warning: we do not have a license for all the songs, special thanks to the composer Liz_thesilent for the music provided. Here is the his links: 
VK group: https://vk.com/lizsanctuary 
Twitch: https://www.twitch.tv/liz_thatsilent


Also thanks to trixq / nnlx for using his song: 
https://open.spotify.com/artist/5NADnia7r8XDEnro4En0wL?si=Alg-FotWQG6RYMEMvufSaA 
https://open.spotify.com/artist/1b417gjtMc3lZBKrsl95Ae?si=EXKmbaJBSW2gJuBcwXpt_A